package com.example.dialer;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    private EditText etNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumber = findViewById(R.id.etNumber);
        Button btnSim1 = findViewById(R.id.btnSim1);
        Button btnSim2 = findViewById(R.id.btnSim2);

        // Both SIM buttons trigger the same logic;
        // Android system handles the actual SIM choice if multiple are present.
        View.OnClickListener callListener = v -> makeCall();
        btnSim1.setOnClickListener(callListener);
        btnSim2.setOnClickListener(callListener);
    }

    // Method called by onClick in XML for digit buttons
    public void onDigitClick(View view) {
        Button b = (Button) view;
        etNumber.append(b.getText().toString());
    }

    private void makeCall() {
        String number = etNumber.getText().toString();
        if (!number.isEmpty()) {
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(Uri.parse("tel:" + number));

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, 1);
                return;
            }
            startActivity(intent);
        }
    }
}