package com.example.exp10;

import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private RadioGroup osRadioGroup;
    private Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        osRadioGroup = findViewById(R.id.osRadioGroup);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(v -> {
            // Get the ID of the selected RadioButton
            int selectedId = osRadioGroup.getCheckedRadioButtonId();

            if (selectedId == -1) {
                Toast.makeText(MainActivity.this, "Please select an option", Toast.LENGTH_SHORT).show();
            } else {
                // Find the RadioButton by the ID
                RadioButton selectedButton = findViewById(selectedId);
                String result = selectedButton.getText().toString();

                Toast.makeText(MainActivity.this, "Excellent Choice: " + result, Toast.LENGTH_LONG).show();
            }
        });
    }
}
// Developed by Piyush Khandelwal