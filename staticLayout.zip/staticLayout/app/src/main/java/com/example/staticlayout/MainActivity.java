package com.example.staticlayout;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FrameLayout container = findViewById(R.id.container);
        container.addView(new MyCanvas(this));
    }

    class MyCanvas extends View {
        Paint paint;

        public MyCanvas(Context context) {
            super(context);
            paint = new Paint();
            paint.setAntiAlias(true);
            paint.setStrokeWidth(8f);
            paint.setTextSize(45f);
            paint.setTextAlign(Paint.Align.CENTER); // This ensures text is centered at the X coordinate
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            // Define Column Centers (Based on Redmi 9A width)
            int col1 = getWidth() / 4;      // Left center
            int col2 = (getWidth() / 4) * 3; // Right center

            // Define Row Centers
            int row1 = 200;
            int row2 = 600;
            int row3 = 1000;

            // --- ROW 1 ---
            // 1. LINE (Blue)
            drawLabel(canvas, "Line", Color.BLUE, col1, row1);
            canvas.drawLine(col1 - 100, row1 + 100, col1 + 100, row1 + 100, paint);

            // 2. CIRCLE (Red)
            drawLabel(canvas, "Circle", Color.RED, col2, row1);
            canvas.drawCircle(col2, row1 + 120, 80, paint);

            // --- ROW 2 ---
            // 3. RECTANGLE (Green)
            drawLabel(canvas, "Rectangle", Color.parseColor("#2E7D32"), col1, row2);
            canvas.drawRect(col1 - 120, row2 + 60, col1 + 120, row2 + 180, paint);

            // 4. SQUARE (Orange)
            drawLabel(canvas, "Square", Color.parseColor("#FF9800"), col2, row2);
            canvas.drawRect(col2 - 80, row2 + 60, col2 + 80, row2 + 220, paint);

            // --- ROW 3 ---
            // 5. TRIANGLE (Purple)
            drawLabel(canvas, "Triangle", Color.parseColor("#9C27B0"), col1, row3);
            Path tri = new Path();
            tri.moveTo(col1, row3 + 60);       // Top point
            tri.lineTo(col1 - 100, row3 + 200); // Bottom left
            tri.lineTo(col1 + 100, row3 + 200); // Bottom right
            tri.close();
            canvas.drawPath(tri, paint);

            // 6. OVAL (Cyan)
            drawLabel(canvas, "Oval", Color.parseColor("#00BCD4"), col2, row3);
            canvas.drawOval(new RectF(col2 - 120, row3 + 80, col2 + 120, row3 + 180), paint);
        }

        private void drawLabel(Canvas canvas, String text, int color, int x, int y) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawText(text, x, y, paint); // Text is now centered automatically
            paint.setStyle(Paint.Style.STROKE);
        }
    }
}