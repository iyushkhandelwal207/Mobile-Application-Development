package com.example.exp6;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db;
    ArrayList<String> ids, contents;
    EditText editNote;
    FloatingActionButton btnAdd;
    RecyclerView recyclerView;
    NotesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        ids = new ArrayList<>();
        contents = new ArrayList<>();

        editNote = findViewById(R.id.editNote);
        btnAdd = findViewById(R.id.btnAdd);
        recyclerView = findViewById(R.id.recyclerView);

        displayNotes();

        btnAdd.setOnClickListener(v -> {
            String note = editNote.getText().toString().trim();
            if (!note.isEmpty()) {
                if (db.insertData(note)) {
                    editNote.setText("");
                    displayNotes();
                }
            }
        });
    }

    void displayNotes() {
        ids.clear();
        contents.clear();
        Cursor cursor = db.getAllData();
        while (cursor.moveToNext()) {
            ids.add(cursor.getString(0));
            contents.add(cursor.getString(1));
        }
        adapter = new NotesAdapter(this, ids, contents, db);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}