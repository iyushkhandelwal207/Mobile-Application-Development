package com.example.exp6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.MyViewHolder> {
    private Context context;
    private ArrayList ids, contents;
    private DatabaseHelper db;

    public NotesAdapter(Context context, ArrayList ids, ArrayList contents, DatabaseHelper db) {
        this.context = context;
        this.ids = ids;
        this.contents = contents;
        this.db = db;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.note_item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.noteText.setText(String.valueOf(contents.get(position)));
        holder.btnDelete.setOnClickListener(v -> {
            db.deleteData(String.valueOf(ids.get(position)));
            ids.remove(position);
            contents.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, contents.size());
        });
    }

    @Override
    public int getItemCount() { return ids.size(); }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView noteText;
        ImageButton btnDelete;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            noteText = itemView.findViewById(R.id.noteText);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}