package com.example.dynamiclayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.*;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private String activeShape = "";
    private MyCanvas canvasView;
    private float drawProgress = 0f; // 0.0 to 1.0 for the slow motion effect

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Drawing area setup
        FrameLayout drawArea = findViewById(R.id.draw_area);
        canvasView = new MyCanvas(this);
        drawArea.addView(canvasView);

        // Shape Button IDs and their corresponding names
        int[] ids = {R.id.btn_line, R.id.btn_circle, R.id.btn_rect, R.id.btn_square, R.id.btn_tri, R.id.btn_oval};
        String[] shapes = {"line", "circle", "rectangle", "square", "triangle", "oval"};

        // Setting up listeners for all 6 buttons
        for(int i=0; i<ids.length; i++) {
            final String s = shapes[i];
            findViewById(ids[i]).setOnClickListener(v -> startAnimatedDrawing(s));
        }

        // Orange Mic Button listener with custom prompt
        findViewById(R.id.btn_voice).setOnClickListener(v -> startVoiceInput());
    }

    private void startVoiceInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());

        // Custom prompt as requested: "Speak like draw rectangle, circle..."
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak like: Draw Rectangle, Circle, etc.");

        try {
            startActivityForResult(intent, 100);
        } catch (Exception e) {
            Toast.makeText(this, "Voice Input not supported on this device", Toast.LENGTH_SHORT).show();
        }
    }

    private void startAnimatedDrawing(String shape) {
        activeShape = shape;
        drawProgress = 0f; // Reset progress for the new shape

        // Slow motion animator: 0 to 1 over 2.5 seconds
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(2500);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(animation -> {
            drawProgress = (float) animation.getAnimatedValue();
            canvasView.invalidate(); // Force redraw to show slow motion progress
        });
        animator.start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String spoken = result.get(0).toLowerCase();

            String found = "";
            if (spoken.contains("line")) found = "line";
            else if (spoken.contains("circle")) found = "circle";
            else if (spoken.contains("rectangle")) found = "rectangle";
            else if (spoken.contains("square")) found = "square";
            else if (spoken.contains("triangle")) found = "triangle";
            else if (spoken.contains("oval")) found = "oval";

            if(!found.isEmpty()) {
                startAnimatedDrawing(found);
            } else {
                Toast.makeText(this, "Shape not recognized. Try again!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Custom Canvas Class for Slow Motion Drawing
    class MyCanvas extends View {
        Paint p = new Paint();
        PathMeasure pathMeasure = new PathMeasure();

        public MyCanvas(Context c) {
            super(c);
            p.setAntiAlias(true);
            p.setStrokeWidth(12f);
            p.setTextSize(55f);
            p.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (activeShape.isEmpty()) return;

            // Center coordinates for Redmi 9A
            int x = getWidth() / 2;
            int y = getHeight() / 2;

            p.setStyle(Paint.Style.STROKE);
            Path fullPath = new Path();

            // Define shapes based on selection
            switch (activeShape) {
                case "line":
                    p.setColor(Color.BLUE);
                    fullPath.moveTo(x - 250, y);
                    fullPath.lineTo(x + 250, y);
                    break;
                case "circle":
                    p.setColor(Color.RED);
                    fullPath.addCircle(x, y, 180, Path.Direction.CW);
                    break;
                case "rectangle":
                    p.setColor(Color.parseColor("#4CAF50"));
                    fullPath.addRect(x - 280, y - 140, x + 280, y + 140, Path.Direction.CW);
                    break;
                case "square":
                    p.setColor(Color.parseColor("#607D8B"));
                    fullPath.addRect(x - 200, y - 200, x + 200, y + 200, Path.Direction.CW);
                    break;
                case "triangle":
                    p.setColor(Color.parseColor("#9C27B0"));
                    fullPath.moveTo(x, y - 200);
                    fullPath.lineTo(x - 220, y + 200);
                    fullPath.lineTo(x + 220, y + 200);
                    fullPath.close();
                    break;
                case "oval":
                    p.setColor(Color.parseColor("#00BCD4"));
                    fullPath.addOval(new RectF(x - 280, y - 160, x + 280, y + 160), Path.Direction.CW);
                    break;
            }

            // SLOW MOTION LOGIC using PathMeasure
            Path drawingPath = new Path();
            pathMeasure.setPath(fullPath, false);
            float length = pathMeasure.getLength();
            pathMeasure.getSegment(0, length * drawProgress, drawingPath, true);

            // Draw the partial path (the "Slow Motion" part)
            canvas.drawPath(drawingPath, p);

            // Draw the Label at the top
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.BLACK); // Label color
            canvas.drawText("SHAPE: " + activeShape.toUpperCase(), x, 100, p);
        }
    }
}