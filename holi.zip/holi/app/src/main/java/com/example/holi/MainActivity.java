package com.example.holi;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private ImageView imgAvatar, splashOverlay, imgPichkari, imgBucket;
    private ProgressBar fillProgressBar;
    private CardView cardContainer;
    private Bitmap overlayBitmap;
    private Canvas splashCanvas;

    private int selectedColor = Color.GREEN;
    private boolean isFilled = false;
    private boolean isPickingColor = false; // Lock for dialog
    private float dX, dY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Views
        imgAvatar = findViewById(R.id.imgAvatar);
        splashOverlay = findViewById(R.id.splashOverlay);
        imgPichkari = findViewById(R.id.imgPichkari);
        imgBucket = findViewById(R.id.imgBucket);
        fillProgressBar = findViewById(R.id.fillProgressBar);
        cardContainer = findViewById(R.id.cardContainer);
        Button btnUpload = findViewById(R.id.btnUpload);
        Button btnDownload = findViewById(R.id.btnDownload);

        // Upload Logic
        btnUpload.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 100);
        });

        // Download Logic
        btnDownload.setOnClickListener(v -> saveFinalImageToGallery());

        // Pichkari Interaction Logic
        setupPichkariInteractions();
    }

    private void setupPichkariInteractions() {
        imgPichkari.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dX = view.getX() - event.getRawX();
                    dY = view.getY() - event.getRawY();
                    break;

                case MotionEvent.ACTION_MOVE:
                    view.setX(event.getRawX() + dX);
                    view.setY(event.getRawY() + dY);
                    checkBucketCollision();
                    break;

                case MotionEvent.ACTION_UP:
                    // Shoot when finger is lifted over the face
                    if (isOverFace() && isFilled) {
                        shootSplash();
                    }
                    break;
            }
            return true;
        });
    }

    private void checkBucketCollision() {
        float centerX1 = imgPichkari.getX() + (imgPichkari.getWidth() / 2f);
        float centerY1 = imgPichkari.getY() + (imgPichkari.getHeight() / 2f);
        float centerX2 = imgBucket.getX() + (imgBucket.getWidth() / 2f);
        float centerY2 = imgBucket.getY() + (imgBucket.getHeight() / 2f);

        double distance = Math.sqrt(Math.pow(centerX1 - centerX2, 2) + Math.pow(centerY1 - centerY2, 2));

        // Use isPickingColor lock to prevent multiple popups
        if (distance < 160 && !isFilled && !isPickingColor && fillProgressBar.getVisibility() != View.VISIBLE) {
            isPickingColor = true;
            showColorPicker();
        }
    }

    private void showColorPicker() {
        String[] colors = {"Red", "Blue", "Green", "Yellow", "Pink", "Orange"};
        int[] colorValues = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.MAGENTA, Color.parseColor("#FF5722")};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Pick a Holi Color");
        builder.setItems(colors, (dialog, which) -> {
            selectedColor = colorValues[which];
            isPickingColor = false;
            startFillingAnimation();
        });
        builder.setOnCancelListener(dialog -> isPickingColor = false);
        builder.setCancelable(true);
        builder.show();
    }

    private void startFillingAnimation() {
        fillProgressBar.setVisibility(View.VISIBLE);
        fillProgressBar.setProgress(0);

        new Handler().postDelayed(() -> {
            isFilled = true;
            fillProgressBar.setVisibility(View.INVISIBLE);
            Toast.makeText(this, "Pichkari Ready! Drag to face & release.", Toast.LENGTH_SHORT).show();
        }, 1200);
    }

    private boolean isOverFace() {
        float pX = imgPichkari.getX() + (imgPichkari.getWidth() / 2f);
        float pY = imgPichkari.getY(); // Top of pichkari

        return (pX > cardContainer.getLeft() && pX < cardContainer.getRight() &&
                pY > cardContainer.getTop() && pY < cardContainer.getBottom());
    }

    private void shootSplash() {
        if (overlayBitmap == null) return;

        Paint paint = new Paint();
        paint.setColor(selectedColor);
        paint.setAlpha(210); // Liquid transparency
        paint.setAntiAlias(true);

        // Adjust coordinates relative to the circular container
        float relativeX = (imgPichkari.getX() + imgPichkari.getWidth()/2) - cardContainer.getLeft();
        float relativeY = imgPichkari.getY() - cardContainer.getTop();

        splashCanvas.drawCircle(relativeX, relativeY, 45, paint);
        splashOverlay.setImageBitmap(overlayBitmap);

        isFilled = false;
    }

    private void saveFinalImageToGallery() {
        try {
            Bitmap finalImage = Bitmap.createBitmap(cardContainer.getWidth(), cardContainer.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(finalImage);
            cardContainer.draw(canvas);

            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "Holi_Piyush_" + System.currentTimeMillis() + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Holi");

            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

            if (uri != null) {
                OutputStream out = getContentResolver().openOutputStream(uri);
                finalImage.compress(Bitmap.CompressFormat.PNG, 100, out);
                if (out != null) out.close();
                Toast.makeText(this, "Image Saved! Check Gallery.", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            imgAvatar.setImageURI(data.getData());
            imgAvatar.post(() -> {
                overlayBitmap = Bitmap.createBitmap(imgAvatar.getWidth(), imgAvatar.getHeight(), Bitmap.Config.ARGB_8888);
                splashCanvas = new Canvas(overlayBitmap);
                splashOverlay.setImageBitmap(overlayBitmap);
            });
        }
    }
}