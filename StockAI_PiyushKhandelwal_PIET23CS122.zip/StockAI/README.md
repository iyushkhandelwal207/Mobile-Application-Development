# StockAI — AI Stock Predictor
**Developer:** Piyush Khandelwal | PIET23CS122  
**Project:** Mobile Application Development Lab — Special Project  
**Tech:** Java · Android Studio · Retrofit · MPAndroidChart · ML Forecasting

---

## How to Open in Android Studio

1. Extract this ZIP folder somewhere on your PC
2. Open **Android Studio**
3. Click **"Open"** → select the `StockAI` folder
4. Wait for Gradle to sync (takes 2–5 minutes first time, needs internet)
5. Connect your **Redmi 9A** via USB, enable **USB Debugging** in Developer Options
6. Click the **▶ Run** button

---

## Get Your Free API Key

1. Visit: https://www.alphavantage.co/support/#api-key
2. Fill the form → get free key instantly
3. Open: `app/src/main/java/com/piyush/stockai/network/RetrofitClient.java`
4. Replace `"demo"` with your key:
   ```java
   public static final String API_KEY = "YOUR_KEY_HERE";
   ```
> **Note:** The app works perfectly WITHOUT an API key using built-in demo data.

---

## App Screens

| Screen | Description |
|--------|-------------|
| Splash | Animated launch screen with your name |
| Home | Watchlist with AI BUY/SELL/HOLD signals |
| Stock Detail | Price chart + full ML prediction breakdown |
| Market | NIFTY/SENSEX indices, Top Gainers & Losers |

---

## ML Algorithm Used

**Moving Average Crossover + RSI + Momentum**

- **Short MA (3-day)** vs **Long MA (7-day)** → trend direction
- **RSI (Relative Strength Index)** → overbought/oversold detection
- **Momentum %** → strength of price movement
- **Confidence Score** → consistency of trend (55–95%)
- **7-day Price Forecast** → Weighted Moving Average projection

This is a real technique used in quantitative finance!

---

## Project Structure

```
StockAI/
├── activities/
│   ├── SplashActivity.java     ← Launch screen
│   ├── MainActivity.java       ← Home + Watchlist
│   ├── StockDetailActivity.java← Chart + AI Prediction
│   └── MarketActivity.java     ← Market Overview
├── adapters/
│   └── StockAdapter.java       ← RecyclerView list
├── models/
│   └── StockModel.java         ← Stock data model
├── network/
│   ├── ApiService.java         ← API endpoints
│   └── RetrofitClient.java     ← HTTP client
└── utils/
    ├── PredictionEngine.java   ← ML prediction logic
    └── DataProvider.java       ← Demo stock data
```

---

*Developed by Piyush Khandelwal | PIET23CS122*
