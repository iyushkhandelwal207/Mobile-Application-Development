package com.piyush.stockai.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.piyush.stockai.R;
import com.piyush.stockai.adapters.StockAdapter;
import com.piyush.stockai.models.StockModel;
import com.piyush.stockai.utils.DataProvider;
import java.util.ArrayList;
import java.util.List;

public class MarketActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_market);

        List<StockModel> all = DataProvider.getAllStocks();

        // Sort gainers (highest change first)
        List<StockModel> gainers = new ArrayList<>(all);
        gainers.sort((a, b) -> Double.compare(b.getChangePercent(), a.getChangePercent()));

        // Sort losers (lowest change first)
        List<StockModel> losers = new ArrayList<>(all);
        losers.sort((a, b) -> Double.compare(a.getChangePercent(), b.getChangePercent()));

        RecyclerView rvGainers = findViewById(R.id.rv_gainers);
        RecyclerView rvLosers  = findViewById(R.id.rv_losers);
        rvGainers.setLayoutManager(new LinearLayoutManager(this));
        rvLosers.setLayoutManager(new LinearLayoutManager(this));
        rvGainers.setNestedScrollingEnabled(false);
        rvLosers.setNestedScrollingEnabled(false);

        rvGainers.setAdapter(new StockAdapter(this, gainers.subList(0, Math.min(5, gainers.size()))));
        rvLosers.setAdapter(new StockAdapter(this, losers.subList(0, Math.min(5, losers.size()))));

        // Market indices
        TextView tvNifty        = findViewById(R.id.tv_nifty_value);
        TextView tvNiftyChange  = findViewById(R.id.tv_nifty_change);
        TextView tvSensex       = findViewById(R.id.tv_sensex_value);
        TextView tvSensexChange = findViewById(R.id.tv_sensex_change);

        tvNifty.setText("22,475");
        tvNiftyChange.setText("▲ +0.43%");
        tvNiftyChange.setTextColor(getResources().getColor(R.color.color_buy));
        tvSensex.setText("73,847");
        tvSensexChange.setText("▲ +0.38%");
        tvSensexChange.setTextColor(getResources().getColor(R.color.color_buy));

        setupBottomNav();
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        bottomNav.setSelectedItemId(R.id.nav_market);
        bottomNav.setOnNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            return true;
        });
    }
}
