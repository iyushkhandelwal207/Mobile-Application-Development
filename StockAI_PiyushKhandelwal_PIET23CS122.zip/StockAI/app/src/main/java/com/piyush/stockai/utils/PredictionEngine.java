package com.piyush.stockai.utils;

/**
 * PredictionEngine — ML-based Stock Trend Forecasting
 * Algorithm: Moving Average Crossover + Momentum Analysis
 * This is a real technique used in quantitative finance.
 *
 * Developed by Piyush Khandelwal | PIET23CS122
 */
public class PredictionEngine {

    private static final String BUY  = "BUY";
    private static final String SELL = "SELL";
    private static final String HOLD = "HOLD";

    /**
     * Predict trend signal using short/long moving average crossover
     */
    public static String predictTrend(double[] prices) {
        if (prices == null || prices.length < 5) return HOLD;

        double shortMA = movingAverage(prices, 3);
        double longMA  = movingAverage(prices, 7);
        double momentum = getMomentum(prices);
        double rsi = calculateRSI(prices);

        // Golden cross: short MA crosses above long MA = BUY
        if (shortMA > longMA && momentum > 1.2 && rsi < 70) {
            return BUY;
        }
        // Death cross: short MA crosses below long MA = SELL
        else if (shortMA < longMA && momentum < -1.2 && rsi > 30) {
            return SELL;
        }
        return HOLD;
    }

    /**
     * Predict next day price using weighted moving average + trend
     */
    public static double predictNextPrice(double[] prices) {
        if (prices == null || prices.length < 2) return 0;
        double wma = weightedMovingAverage(prices, Math.min(prices.length, 5));
        double trend = prices[prices.length - 1] - prices[prices.length - 2];
        return wma + (trend * 0.55);
    }

    /**
     * Predict price for N days ahead
     */
    public static double predictPriceInDays(double[] prices, int days) {
        double[] extended = prices.clone();
        for (int i = 0; i < days; i++) {
            double next = predictNextPrice(extended);
            double[] newArr = new double[extended.length + 1];
            System.arraycopy(extended, 0, newArr, 0, extended.length);
            newArr[extended.length] = next;
            extended = newArr;
        }
        return extended[extended.length - 1];
    }

    /**
     * Confidence score: how consistent is the trend (0-100)
     */
    public static int getConfidence(double[] prices) {
        if (prices == null || prices.length < 3) return 50;
        int consistent = 0;
        boolean firstTrend = prices[1] > prices[0];
        for (int i = 1; i < prices.length; i++) {
            if ((prices[i] > prices[i - 1]) == firstTrend) consistent++;
        }
        int base = (consistent * 100) / (prices.length - 1);
        // Scale to 55–95 range — no prediction is 100% certain
        return 55 + (int) (base * 0.4);
    }

    /**
     * Bullish probability percentage
     */
    public static int getBullishPercent(double[] prices) {
        String trend = predictTrend(prices);
        int conf = getConfidence(prices);
        if (trend.equals(BUY))  return conf;
        if (trend.equals(SELL)) return 100 - conf;
        return 50;
    }

    /**
     * Simple Moving Average
     */
    public static double movingAverage(double[] data, int period) {
        if (data.length == 0) return 0;
        double sum = 0;
        int start = Math.max(0, data.length - period);
        int count = data.length - start;
        for (int i = start; i < data.length; i++) sum += data[i];
        return sum / count;
    }

    /**
     * Weighted Moving Average (recent prices matter more)
     */
    public static double weightedMovingAverage(double[] data, int period) {
        if (data.length == 0) return 0;
        int start = Math.max(0, data.length - period);
        double sum = 0, weightSum = 0;
        int weight = 1;
        for (int i = start; i < data.length; i++) {
            sum += data[i] * weight;
            weightSum += weight;
            weight++;
        }
        return sum / weightSum;
    }

    /**
     * Momentum: percentage change over the whole period
     */
    public static double getMomentum(double[] prices) {
        if (prices.length < 2) return 0;
        double first = prices[0];
        double last  = prices[prices.length - 1];
        if (first == 0) return 0;
        return ((last - first) / first) * 100;
    }

    /**
     * Relative Strength Index (RSI) — overbought/oversold indicator
     * RSI > 70 = overbought (might fall), RSI < 30 = oversold (might rise)
     */
    public static double calculateRSI(double[] prices) {
        if (prices.length < 2) return 50;
        double gains = 0, losses = 0;
        for (int i = 1; i < prices.length; i++) {
            double diff = prices[i] - prices[i - 1];
            if (diff > 0) gains  += diff;
            else          losses -= diff;
        }
        if (losses == 0) return 100;
        double rs = gains / losses;
        return 100 - (100 / (1 + rs));
    }

    /**
     * Human-readable confidence label
     */
    public static String getConfidenceLabel(int confidence) {
        if (confidence >= 80) return "High";
        if (confidence >= 65) return "Medium";
        return "Low";
    }
}
