package com.piyush.stockai.activities;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.MarkerView;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.piyush.stockai.R;
import com.piyush.stockai.utils.DataProvider;
import com.piyush.stockai.utils.PortfolioManager;
import com.piyush.stockai.utils.PredictionEngine;
import java.util.ArrayList;
import java.util.List;

public class StockDetailActivity extends AppCompatActivity {

    private LineChart lineChart;
    private TextView tvSymbol, tvCompany, tvPrice, tvChange;
    private TextView tvSignal, tvConfidence, tvTarget;
    private TextView tvBullPct, tvNeutralPct, tvBearPct;
    private TextView tvRsi, tvMomentum, tvSma;
    private TextView tvTouchPrice, tvHolding, tvBalance;
    private String symbol, company, signal;
    private double price, change, target;
    private int confidence;
    private double[] history;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock_detail);

        symbol     = getIntent().getStringExtra("symbol");
        company    = getIntent().getStringExtra("company");
        price      = getIntent().getDoubleExtra("price", 0);
        change     = getIntent().getDoubleExtra("change", 0);
        signal     = getIntent().getStringExtra("signal");
        confidence = getIntent().getIntExtra("confidence", 50);
        target     = getIntent().getDoubleExtra("target", 0);
        history    = DataProvider.getExtendedHistory(symbol);

        initViews();
        populateHeader();
        setupChart();
        populatePrediction();
        setupBuySell();
        updateHoldingInfo();
        setupBackButton();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateHoldingInfo();
    }

    private void initViews() {
        lineChart    = findViewById(R.id.line_chart);
        tvSymbol     = findViewById(R.id.tv_detail_symbol);
        tvCompany    = findViewById(R.id.tv_detail_company);
        tvPrice      = findViewById(R.id.tv_detail_price);
        tvChange     = findViewById(R.id.tv_detail_change);
        tvSignal     = findViewById(R.id.tv_detail_signal);
        tvConfidence = findViewById(R.id.tv_confidence_value);
        tvTarget     = findViewById(R.id.tv_target_value);
        tvBullPct    = findViewById(R.id.tv_bull_pct);
        tvNeutralPct = findViewById(R.id.tv_neutral_pct);
        tvBearPct    = findViewById(R.id.tv_bear_pct);
        tvRsi        = findViewById(R.id.tv_rsi_value);
        tvMomentum   = findViewById(R.id.tv_momentum_value);
        tvSma        = findViewById(R.id.tv_sma_value);
        tvTouchPrice = findViewById(R.id.tv_touch_price);
        tvHolding    = findViewById(R.id.tv_holding_info);
        tvBalance    = findViewById(R.id.tv_balance_info);
    }

    private void populateHeader() {
        tvSymbol.setText(symbol);
        tvCompany.setText(company + " · NSE");
        tvPrice.setText(String.format("₹%.2f", price));
        String sign = change >= 0 ? "▲ +" : "▼ ";
        tvChange.setText(String.format("%s%.2f%%", sign, change));
        tvChange.setTextColor(getResources().getColor(
                change >= 0 ? R.color.color_buy : R.color.color_sell));
    }

    private void setupChart() {
        List<Entry> historicalEntries = new ArrayList<>();
        List<Entry> predictionEntries = new ArrayList<>();

        for (int i = 0; i < history.length; i++) {
            historicalEntries.add(new Entry(i, (float) history[i]));
        }
        predictionEntries.add(new Entry(history.length - 1, (float) history[history.length - 1]));
        predictionEntries.add(new Entry(history.length + 2, (float) target));
        predictionEntries.add(new Entry(history.length + 4, (float) (target * 1.006)));

        // Historical line
        LineDataSet histSet = new LineDataSet(historicalEntries, "Price History");
        histSet.setColor(0xFF3B82F6);
        histSet.setLineWidth(2.5f);
        histSet.setDrawCircles(false);
        histSet.setDrawValues(false);
        histSet.setDrawFilled(true);
        histSet.setFillColor(0xFF1A2744);
        histSet.setFillAlpha(90);
        histSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        histSet.setHighlightLineWidth(1.5f);
        histSet.setHighLightColor(0xFFA78BFA);
        histSet.setDrawHighlightIndicators(true);

        // Prediction dashed line
        LineDataSet predSet = new LineDataSet(predictionEntries, "AI Forecast");
        predSet.setColor(0xFFA78BFA);
        predSet.setLineWidth(2f);
        predSet.setCircleRadius(5f);
        predSet.setCircleColor(0xFFA78BFA);
        predSet.setDrawValues(false);
        predSet.enableDashedLine(12f, 6f, 0f);
        predSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        predSet.setHighlightLineWidth(1.5f);
        predSet.setHighLightColor(0xFFA78BFA);

        lineChart.setData(new LineData(histSet, predSet));
        styleChart();

        // ── TOUCH TO SEE VALUE ──
        lineChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                tvTouchPrice.setVisibility(View.VISIBLE);
                tvTouchPrice.setText(String.format("📍 ₹%.2f  at Day %d", e.getY(), (int) e.getX() + 1));
            }
            @Override
            public void onNothingSelected() {
                tvTouchPrice.setVisibility(View.GONE);
            }
        });

        lineChart.invalidate();
    }

    private void styleChart() {
        lineChart.setBackgroundColor(Color.parseColor("#11161F"));
        lineChart.getDescription().setEnabled(false);
        lineChart.getLegend().setEnabled(false);
        lineChart.setTouchEnabled(true);
        lineChart.setDragEnabled(true);
        lineChart.setScaleEnabled(true);
        lineChart.setPinchZoom(true);
        lineChart.setDrawBorders(false);
        lineChart.setExtraBottomOffset(10f);
        lineChart.setExtraLeftOffset(8f);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setDrawAxisLine(false);
        xAxis.setTextColor(Color.parseColor("#4B5563"));
        xAxis.setTextSize(9f);
        xAxis.setLabelCount(6);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int v = (int) value;
                if (v < history.length) return "D" + (v + 1);
                return "F" + (v - history.length + 1);
            }
        });

        YAxis leftAxis = lineChart.getAxisLeft();
        leftAxis.setDrawGridLines(true);
        leftAxis.setGridColor(Color.parseColor("#1C2230"));
        leftAxis.setGridLineWidth(0.5f);
        leftAxis.setDrawAxisLine(false);
        leftAxis.setTextColor(Color.parseColor("#4B5563"));
        leftAxis.setTextSize(9f);
        leftAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                if (value >= 1000) return "₹" + (int)(value/1000) + "K";
                return "₹" + (int) value;
            }
        });

        lineChart.getAxisRight().setEnabled(false);
    }

    private void populatePrediction() {
        tvSignal.setText("AI Signal: " + signal);
        switch (signal != null ? signal : "HOLD") {
            case "BUY":
                tvSignal.setBackgroundResource(R.drawable.badge_buy);
                tvSignal.setTextColor(getResources().getColor(R.color.color_buy));
                break;
            case "SELL":
                tvSignal.setBackgroundResource(R.drawable.badge_sell);
                tvSignal.setTextColor(getResources().getColor(R.color.color_sell));
                break;
            default:
                tvSignal.setBackgroundResource(R.drawable.badge_hold);
                tvSignal.setTextColor(getResources().getColor(R.color.color_hold));
        }

        tvConfidence.setText(PredictionEngine.getConfidenceLabel(confidence) + " (" + confidence + "%)");
        tvTarget.setText(String.format("₹%.2f", target));

        int bullish = PredictionEngine.getBullishPercent(history);
        int bearish = Math.max(100 - bullish - 15, 5);
        int neutral = 100 - bullish - bearish;

        tvBullPct.setText(bullish + "%");
        tvNeutralPct.setText(neutral + "%");
        tvBearPct.setText(bearish + "%");

        double rsi      = PredictionEngine.calculateRSI(history);
        double momentum = PredictionEngine.getMomentum(history);
        double sma      = PredictionEngine.movingAverage(history, 7);

        tvRsi.setText(String.format("%.1f", rsi));
        tvMomentum.setText(String.format("%.2f%%", momentum));
        tvSma.setText(String.format("₹%.0f", sma));

        if (rsi > 70) tvRsi.setTextColor(getResources().getColor(R.color.color_sell));
        else if (rsi < 30) tvRsi.setTextColor(getResources().getColor(R.color.color_buy));
        else tvRsi.setTextColor(getResources().getColor(R.color.color_hold));
    }

    private void updateHoldingInfo() {
        PortfolioManager pm = PortfolioManager.getInstance(this);
        int holding = pm.getHolding(symbol);
        double balance = pm.getBalance();

        if (holding > 0) {
            tvHolding.setText("You hold: " + holding + " shares  (₹" + String.format("%.0f", holding * price) + ")");
            tvHolding.setTextColor(getResources().getColor(R.color.color_buy));
        } else {
            tvHolding.setText("You hold: 0 shares");
            tvHolding.setTextColor(getResources().getColor(R.color.text_secondary));
        }
        tvBalance.setText("Virtual Balance: ₹" + String.format("%.0f", balance));
    }

    private void setupBuySell() {
        TextView btnBuy  = findViewById(R.id.btn_buy);
        TextView btnSell = findViewById(R.id.btn_sell);

        btnBuy.setOnClickListener(v -> showTradeDialog("BUY"));
        btnSell.setOnClickListener(v -> showTradeDialog("SELL"));
    }

    private void showTradeDialog(String type) {
        PortfolioManager pm = PortfolioManager.getInstance(this);
        boolean isBuy = type.equals("BUY");

        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.DialogTheme);
        builder.setTitle((isBuy ? "🟢 Buy " : "🔴 Sell ") + symbol);

        View dialogView = getLayoutInflater().inflate(R.layout.dialog_trade, null);
        builder.setView(dialogView);

        EditText etQty = dialogView.findViewById(R.id.et_quantity);
        TextView tvDialogPrice = dialogView.findViewById(R.id.tv_dialog_price);
        TextView tvDialogInfo  = dialogView.findViewById(R.id.tv_dialog_info);

        tvDialogPrice.setText(String.format("Price: ₹%.2f per share", price));

        if (isBuy) {
            tvDialogInfo.setText(String.format("Available Balance: ₹%.0f", pm.getBalance()));
        } else {
            int holding = pm.getHolding(symbol);
            tvDialogInfo.setText("You currently hold: " + holding + " shares");
        }

        builder.setPositiveButton(type, (dialog, which) -> {
            String qtyStr = etQty.getText().toString().trim();
            if (qtyStr.isEmpty()) {
                Toast.makeText(this, "Enter quantity", Toast.LENGTH_SHORT).show();
                return;
            }
            int qty = Integer.parseInt(qtyStr);
            if (qty <= 0) {
                Toast.makeText(this, "Enter valid quantity", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isBuy) {
                boolean success = pm.buyStock(symbol, company, price, qty);
                if (success) {
                    Toast.makeText(this,
                        "✅ Bought " + qty + " shares of " + symbol + " @ ₹" + String.format("%.2f", price),
                        Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this,
                        "❌ Insufficient balance! Need ₹" + String.format("%.0f", price * qty),
                        Toast.LENGTH_LONG).show();
                }
            } else {
                int holding = pm.getHolding(symbol);
                if (qty > holding) {
                    Toast.makeText(this,
                        "❌ You only hold " + holding + " shares",
                        Toast.LENGTH_SHORT).show();
                } else {
                    pm.sellStock(symbol, company, price, qty);
                    Toast.makeText(this,
                        "✅ Sold " + qty + " shares of " + symbol + " @ ₹" + String.format("%.2f", price),
                        Toast.LENGTH_LONG).show();
                }
            }
            updateHoldingInfo();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void setupBackButton() {
        findViewById(R.id.tv_back).setOnClickListener(v -> finish());
    }
}
