package com.piyush.stockai.network;

import com.google.gson.JsonObject;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {

    // Get daily time series for a stock
    @GET("query")
    Call<JsonObject> getDailyTimeSeries(
            @Query("function") String function,
            @Query("symbol") String symbol,
            @Query("outputsize") String outputsize,
            @Query("apikey") String apiKey
    );

    // Get real-time quote
    @GET("query")
    Call<JsonObject> getQuote(
            @Query("function") String function,
            @Query("symbol") String symbol,
            @Query("apikey") String apiKey
    );

    // Search for stocks by keyword
    @GET("query")
    Call<JsonObject> searchSymbol(
            @Query("function") String function,
            @Query("keywords") String keywords,
            @Query("apikey") String apiKey
    );
}
