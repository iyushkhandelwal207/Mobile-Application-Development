package com.piyush.stockai.utils;

import com.piyush.stockai.models.StockModel;
import java.util.ArrayList;
import java.util.List;

/**
 * Extended stock database — 55 Indian stocks across all sectors.
 * Developed by Piyush Khandelwal | PIET23CS122
 */
public class DataProvider {

    private static List<StockModel> cachedStocks = null;

    public static List<StockModel> getAllStocks() {
        if (cachedStocks != null) return cachedStocks;
        List<StockModel> list = new ArrayList<>();

        // IT
        list.add(make("TCS",        "Tata Consultancy Svc",  3421, -0.76, p(3550,3530,3500,3480,3460,3440,3421)));
        list.add(make("INFY",       "Infosys Ltd",           1762,  0.11, p(1700,1710,1720,1715,1740,1750,1762)));
        list.add(make("WIPRO",      "Wipro Ltd",              465,  0.65, p(450,445,448,455,460,458,465)));
        list.add(make("HCLTECH",    "HCL Technologies",      1520,  1.20, p(1480,1490,1500,1510,1505,1518,1520)));
        list.add(make("TECHM",      "Tech Mahindra",         1340,  0.88, p(1300,1310,1320,1315,1330,1338,1340)));
        list.add(make("LTIM",       "LTIMindtree",           5200,  1.10, p(5050,5080,5100,5150,5160,5195,5200)));

        // Finance
        list.add(make("HDFCBANK",   "HDFC Bank",             1640,  0.92, p(1580,1590,1600,1610,1620,1625,1640)));
        list.add(make("ICICIBANK",  "ICICI Bank",            1020,  1.34, p(980,985,990,1000,1008,1012,1020)));
        list.add(make("SBIN",       "State Bank of India",    820,  2.10, p(790,795,800,808,812,815,820)));
        list.add(make("KOTAKBANK",  "Kotak Mahindra Bank",   1780,  0.45, p(1760,1762,1768,1770,1775,1779,1780)));
        list.add(make("AXISBANK",   "Axis Bank",             1120,  1.05, p(1090,1095,1100,1108,1112,1118,1120)));
        list.add(make("BAJFINANCE", "Bajaj Finance",         7380, -0.27, p(7100,7200,7300,7280,7350,7400,7380)));
        list.add(make("BAJAJFINSV", "Bajaj Finserv",         1620,  0.55, p(1590,1595,1600,1608,1612,1618,1620)));
        list.add(make("PNB",        "Punjab National Bank",   120,  1.68, p(110,112,114,116,118,119,120)));
        list.add(make("BANKBARODA", "Bank of Baroda",         250,  0.80, p(240,242,244,246,248,249,250)));

        // Energy
        list.add(make("RELIANCE",   "Reliance Industries",   2847,  1.83, p(2700,2720,2740,2760,2800,2820,2847)));
        list.add(make("ONGC",       "Oil & Nat Gas Corp",     280,  0.72, p(270,272,274,276,278,279,280)));
        list.add(make("NTPC",       "NTPC Ltd",               380,  1.05, p(365,368,370,374,376,379,380)));
        list.add(make("POWERGRID",  "Power Grid Corp",        320,  0.63, p(310,312,314,316,318,319,320)));
        list.add(make("COALINDIA",  "Coal India",             450,  0.89, p(435,438,440,442,445,449,450)));
        list.add(make("IOC",        "Indian Oil Corp",        180,  1.11, p(172,174,175,176,177,178,180)));
        list.add(make("BPCL",       "Bharat Petroleum",       620,  0.97, p(600,605,608,610,614,618,620)));
        list.add(make("TATAPOWER",  "Tata Power Co",          430,  2.38, p(400,408,412,418,422,426,430)));

        // FMCG & Consumer
        list.add(make("ITC",        "ITC Limited",            448,  1.36, p(430,435,432,440,438,442,448)));
        list.add(make("HINDUNILVR", "Hindustan Unilever",    2520, -0.34, p(2540,2535,2530,2525,2522,2521,2520)));
        list.add(make("NESTLEIND",  "Nestle India",          2400,  0.50, p(2370,2375,2380,2388,2392,2398,2400)));
        list.add(make("BRITANNIA",  "Britannia Industries",  5200,  0.78, p(5150,5155,5160,5170,5175,5195,5200)));
        list.add(make("DABUR",      "Dabur India",            580, -0.17, p(585,583,582,581,580,581,580)));
        list.add(make("MARICO",     "Marico Ltd",             620,  0.32, p(610,612,614,616,618,619,620)));
        list.add(make("COLPAL",     "Colgate-Palmolive",     2800,  0.71, p(2760,2765,2770,2780,2785,2795,2800)));

        // Auto
        list.add(make("MARUTI",     "Maruti Suzuki India",  12500,  1.20, p(12100,12200,12250,12300,12350,12450,12500)));
        list.add(make("TATAMOTORS", "Tata Motors",           1020,  3.05, p(950,960,970,980,995,1010,1020)));
        list.add(make("M&M",        "Mahindra & Mahindra",   2100,  1.55, p(2020,2040,2060,2070,2080,2090,2100)));
        list.add(make("BAJAJ-AUTO", "Bajaj Auto",            9200,  0.88, p(9000,9050,9080,9100,9120,9170,9200)));
        list.add(make("HEROMOTOCO", "Hero MotoCorp",         5100,  0.44, p(5030,5040,5055,5065,5075,5090,5100)));
        list.add(make("EICHERMOT",  "Eicher Motors",         4800,  1.26, p(4680,4700,4720,4740,4760,4780,4800)));

        // Pharma
        list.add(make("SUNPHARMA",  "Sun Pharmaceutical",   1680,  0.96, p(1640,1645,1650,1658,1665,1672,1680)));
        list.add(make("DRREDDY",    "Dr Reddy's Labs",       6200,  0.51, p(6150,6158,6165,6172,6180,6192,6200)));
        list.add(make("CIPLA",      "Cipla Ltd",             1520,  1.34, p(1480,1488,1495,1500,1508,1514,1520)));
        list.add(make("APOLLOHOSP", "Apollo Hospitals",      6800,  1.47, p(6650,6670,6690,6720,6740,6770,6800)));

        // Telecom
        list.add(make("BHARTIARTL", "Bharti Airtel",        1620,  2.53, p(1540,1555,1565,1580,1595,1610,1620)));
        list.add(make("IDEA",       "Vodafone Idea",           18,  4.65, p(14,15,15,16,16,17,18)));

        // Consumer Electronics & D2C
        list.add(make("BOAT",       "boAt Lifestyle",         420,  2.86, p(390,395,398,405,410,415,420)));
        list.add(make("DIXON",      "Dixon Technologies",    9800,  3.12, p(9300,9400,9480,9560,9640,9720,9800)));
        list.add(make("AMBER",      "Amber Enterprises",     4200,  1.90, p(4050,4080,4110,4140,4160,4180,4200)));
        list.add(make("KAYNES",     "Kaynes Technology",     4600,  2.44, p(4380,4410,4440,4480,4520,4560,4600)));

        // Metals
        list.add(make("TATASTEEL",  "Tata Steel",             180,  1.69, p(170,172,174,176,177,178,180)));
        list.add(make("JSWSTEEL",   "JSW Steel",              980,  2.08, p(940,950,958,962,968,975,980)));
        list.add(make("HINDALCO",   "Hindalco Industries",    680,  1.49, p(650,655,660,665,670,675,680)));
        list.add(make("VEDL",       "Vedanta Ltd",            480,  2.13, p(455,460,465,468,472,476,480)));

        // Real Estate & Cement
        list.add(make("DLF",        "DLF Ltd",                920,  1.32, p(880,888,895,900,908,914,920)));
        list.add(make("ULTRACEMCO", "UltraTech Cement",     10800,  0.65, p(10650,10680,10700,10730,10760,10780,10800)));
        list.add(make("ADANIPORTS", "Adani Ports",           1380,  2.10, p(1320,1330,1340,1350,1360,1375,1380)));
        list.add(make("ADANIENT",   "Adani Enterprises",    2850,  1.75, p(2720,2740,2760,2780,2800,2840,2850)));

        cachedStocks = list;
        return list;
    }

    public static List<StockModel> getDemoStocks() {
        List<StockModel> all = getAllStocks();
        String[] featured = {"RELIANCE","TCS","INFY","HDFCBANK","TATAMOTORS","BOAT","BHARTIARTL"};
        List<StockModel> demo = new ArrayList<>();
        for (String sym : featured) {
            StockModel s = findBySymbol(sym);
            if (s != null) demo.add(s);
        }
        return demo;
    }

    public static StockModel findBySymbol(String symbol) {
        for (StockModel s : getAllStocks()) {
            if (s.getSymbol().equalsIgnoreCase(symbol)) return s;
        }
        return null;
    }

    public static List<StockModel> search(String query) {
        String q = query.toLowerCase().trim();
        if (q.isEmpty()) return getDemoStocks();
        List<StockModel> results = new ArrayList<>();
        for (StockModel s : getAllStocks()) {
            if (s.getSymbol().toLowerCase().contains(q) ||
                s.getCompanyName().toLowerCase().contains(q)) {
                results.add(s);
            }
        }
        return results;
    }

    public static double[] getExtendedHistory(String symbol) {
        StockModel s = findBySymbol(symbol);
        if (s != null && s.getPriceHistory() != null) {
            double[] base = s.getPriceHistory();
            double[] extended = new double[14];
            double start = base[0] * 0.95;
            double end   = base[base.length - 1];
            for (int i = 0; i < 14; i++) {
                double ratio = (double) i / 13;
                double trend = start + (end - start) * ratio;
                // small deterministic variation based on index
                double noise = ((i % 3 == 0 ? 1 : -1) * end * 0.004);
                extended[i] = trend + noise;
            }
            extended[13] = end;
            return extended;
        }
        return new double[]{100,102,101,105,107,106,108,110,109,112,114,115,116,117};
    }

    private static double[] p(double... vals) { return vals; }

    private static StockModel make(String sym, String name, double price,
                                   double change, double[] history) {
        StockModel s = new StockModel(sym, name, price, change, history);
        s.setSignal(PredictionEngine.predictTrend(history));
        s.setConfidence(PredictionEngine.getConfidence(history));
        s.setTargetPrice(PredictionEngine.predictPriceInDays(history, 7));
        return s;
    }
}
