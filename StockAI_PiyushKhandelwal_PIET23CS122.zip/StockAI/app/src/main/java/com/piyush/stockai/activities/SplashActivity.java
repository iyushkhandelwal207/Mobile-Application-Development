package com.piyush.stockai.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.piyush.stockai.R;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView tvLogo    = findViewById(R.id.tv_logo);
        TextView tvTagline = findViewById(R.id.tv_tagline);
        TextView tvFooter  = findViewById(R.id.tv_footer);

        // Fade-in animation
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(1200);
        fadeIn.setFillAfter(true);
        tvLogo.startAnimation(fadeIn);

        AlphaAnimation fadeIn2 = new AlphaAnimation(0f, 1f);
        fadeIn2.setDuration(1200);
        fadeIn2.setStartOffset(400);
        fadeIn2.setFillAfter(true);
        tvTagline.startAnimation(fadeIn2);

        AlphaAnimation fadeIn3 = new AlphaAnimation(0f, 1f);
        fadeIn3.setDuration(1000);
        fadeIn3.setStartOffset(800);
        fadeIn3.setFillAfter(true);
        tvFooter.startAnimation(fadeIn3);

        // Navigate to MainActivity after 2.5 seconds
        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        }, 2500);
    }
}
