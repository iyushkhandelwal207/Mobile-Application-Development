package com.piyush.stockai.models;

public class PortfolioItem {
    private String symbol;
    private String companyName;
    private double buyPrice;
    private int quantity;
    private long timestamp;
    private String type; // "BUY" or "SELL"

    public PortfolioItem(String symbol, String companyName, double buyPrice,
                         int quantity, String type) {
        this.symbol = symbol;
        this.companyName = companyName;
        this.buyPrice = buyPrice;
        this.quantity = quantity;
        this.type = type;
        this.timestamp = System.currentTimeMillis();
    }

    public String getSymbol() { return symbol; }
    public String getCompanyName() { return companyName; }
    public double getBuyPrice() { return buyPrice; }
    public int getQuantity() { return quantity; }
    public long getTimestamp() { return timestamp; }
    public String getType() { return type; }

    public double getTotalValue() { return buyPrice * quantity; }

    public double getProfitLoss(double currentPrice) {
        double current = currentPrice * quantity;
        double invested = buyPrice * quantity;
        return type.equals("BUY") ? current - invested : invested - current;
    }

    public double getProfitLossPercent(double currentPrice) {
        double pl = getProfitLoss(currentPrice);
        return (pl / getTotalValue()) * 100;
    }
}
