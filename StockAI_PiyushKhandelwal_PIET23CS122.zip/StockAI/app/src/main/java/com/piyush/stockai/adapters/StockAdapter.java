package com.piyush.stockai.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.piyush.stockai.R;
import com.piyush.stockai.activities.StockDetailActivity;
import com.piyush.stockai.models.StockModel;
import java.util.List;

public class StockAdapter extends RecyclerView.Adapter<StockAdapter.ViewHolder> {

    private Context context;
    private List<StockModel> stockList;

    public StockAdapter(Context context, List<StockModel> stockList) {
        this.context = context;
        this.stockList = stockList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_stock, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        StockModel stock = stockList.get(position);

        holder.tvInitials.setText(stock.getInitials());
        holder.tvSymbol.setText(stock.getSymbol());
        holder.tvCompany.setText(stock.getCompanyName());
        holder.tvPrice.setText(stock.getFormattedPrice());
        holder.tvChange.setText(stock.getFormattedChange());

        // Color the change text
        if (stock.isPositive()) {
            holder.tvChange.setTextColor(context.getResources().getColor(R.color.color_buy));
        } else {
            holder.tvChange.setTextColor(context.getResources().getColor(R.color.color_sell));
        }

        // Signal badge
        String signal = stock.getSignal();
        holder.tvSignal.setText(signal);
        switch (signal) {
            case "BUY":
                holder.tvSignal.setBackgroundResource(R.drawable.badge_buy);
                holder.tvSignal.setTextColor(context.getResources().getColor(R.color.color_buy));
                break;
            case "SELL":
                holder.tvSignal.setBackgroundResource(R.drawable.badge_sell);
                holder.tvSignal.setTextColor(context.getResources().getColor(R.color.color_sell));
                break;
            default:
                holder.tvSignal.setBackgroundResource(R.drawable.badge_hold);
                holder.tvSignal.setTextColor(context.getResources().getColor(R.color.color_hold));
                break;
        }

        // Icon background color based on position
        int[] iconColors = {0xFF0D1F3C, 0xFF1C1208, 0xFF130D2A, 0xFF0A1F14, 0xFF1A1010};
        holder.cardIcon.setCardBackgroundColor(iconColors[position % iconColors.length]);

        // Click to open detail
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, StockDetailActivity.class);
            intent.putExtra("symbol", stock.getSymbol());
            intent.putExtra("company", stock.getCompanyName());
            intent.putExtra("price", stock.getCurrentPrice());
            intent.putExtra("change", stock.getChangePercent());
            intent.putExtra("signal", stock.getSignal());
            intent.putExtra("confidence", stock.getConfidence());
            intent.putExtra("target", stock.getTargetPrice());
            intent.putExtra("history", stock.getPriceHistory());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() { return stockList.size(); }

    public void updateList(List<StockModel> newList) {
        stockList = newList;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardIcon;
        TextView tvInitials, tvSymbol, tvCompany, tvPrice, tvChange, tvSignal;

        ViewHolder(View itemView) {
            super(itemView);
            cardIcon   = itemView.findViewById(R.id.card_icon);
            tvInitials = itemView.findViewById(R.id.tv_initials);
            tvSymbol   = itemView.findViewById(R.id.tv_symbol);
            tvCompany  = itemView.findViewById(R.id.tv_company);
            tvPrice    = itemView.findViewById(R.id.tv_price);
            tvChange   = itemView.findViewById(R.id.tv_change);
            tvSignal   = itemView.findViewById(R.id.tv_signal);
        }
    }
}
