package com.piyush.stockai.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.piyush.stockai.R;
import com.piyush.stockai.adapters.TransactionAdapter;
import com.piyush.stockai.models.PortfolioItem;
import com.piyush.stockai.utils.DataProvider;
import com.piyush.stockai.utils.PortfolioManager;
import java.util.List;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        loadProfile();
        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProfile();
    }

    private void loadProfile() {
        PortfolioManager pm = PortfolioManager.getInstance(this);
        List<PortfolioItem> transactions = pm.getTransactions();

        // Header stats
        TextView tvName      = findViewById(R.id.tv_profile_name);
        TextView tvRoll      = findViewById(R.id.tv_profile_roll);
        TextView tvBalance   = findViewById(R.id.tv_profile_balance);
        TextView tvInvested  = findViewById(R.id.tv_profile_invested);
        TextView tvPL        = findViewById(R.id.tv_profile_pl);
        TextView tvTxCount   = findViewById(R.id.tv_tx_count);
        TextView tvNoTx      = findViewById(R.id.tv_no_transactions);

        tvName.setText("Piyush Khandelwal");
        tvRoll.setText("PIET23CS122  ·  AI Stock Predictor");

        double balance  = pm.getBalance();
        double invested = pm.getTotalInvested();

        // Calculate current portfolio value using live prices
        double currentValue = 0;
        for (String sym : getHeldSymbols(transactions)) {
            int holding = pm.getHolding(sym);
            if (holding > 0) {
                com.piyush.stockai.models.StockModel s = DataProvider.findBySymbol(sym);
                if (s != null) currentValue += holding * s.getCurrentPrice();
            }
        }

        double totalAssets = balance + currentValue;
        double startingBalance = 100000.0;
        double pl = totalAssets - startingBalance;
        double plPct = (pl / startingBalance) * 100;

        tvBalance.setText(String.format("₹%.0f", balance));
        tvInvested.setText(String.format("₹%.0f", currentValue));

        String plText = String.format("%s₹%.0f (%.2f%%)",
                pl >= 0 ? "▲ +" : "▼ ", Math.abs(pl), Math.abs(plPct));
        tvPL.setText(plText);
        tvPL.setTextColor(getResources().getColor(pl >= 0 ? R.color.color_buy : R.color.color_sell));

        tvTxCount.setText(transactions.size() + " Transactions");

        // Transactions list
        RecyclerView rv = findViewById(R.id.rv_transactions);
        rv.setLayoutManager(new LinearLayoutManager(this));

        if (transactions.isEmpty()) {
            tvNoTx.setVisibility(android.view.View.VISIBLE);
            rv.setVisibility(android.view.View.GONE);
        } else {
            tvNoTx.setVisibility(android.view.View.GONE);
            rv.setVisibility(android.view.View.VISIBLE);
            // Show newest first
            java.util.Collections.reverse(transactions);
            rv.setAdapter(new TransactionAdapter(this, transactions));
        }

        // Reset button
        findViewById(R.id.btn_reset).setOnClickListener(v -> {
            new androidx.appcompat.app.AlertDialog.Builder(this, R.style.DialogTheme)
                .setTitle("Reset Portfolio?")
                .setMessage("This will clear all transactions and reset your balance to ₹1,00,000. Are you sure?")
                .setPositiveButton("Reset", (d, w) -> {
                    pm.resetPortfolio();
                    loadProfile();
                })
                .setNegativeButton("Cancel", null)
                .show();
        });
    }

    private java.util.Set<String> getHeldSymbols(List<PortfolioItem> items) {
        java.util.Set<String> syms = new java.util.HashSet<>();
        for (PortfolioItem item : items) syms.add(item.getSymbol());
        return syms;
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        bottomNav.setSelectedItemId(R.id.nav_profile);
        bottomNav.setOnNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                startActivity(new Intent(this, MainActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            } else if (id == R.id.nav_market) {
                startActivity(new Intent(this, MarketActivity.class));
                overridePendingTransition(0, 0);
                finish();
                return true;
            }
            return true;
        });
    }
}
