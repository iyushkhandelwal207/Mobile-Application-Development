package com.piyush.stockai.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.piyush.stockai.models.PortfolioItem;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PortfolioManager {

    private static final String PREF_NAME = "stockai_portfolio";
    private static final String KEY_ITEMS = "portfolio_items";
    private static final String KEY_BALANCE = "virtual_balance";
    private static final double STARTING_BALANCE = 100000.0; // ₹1,00,000 virtual money

    private static PortfolioManager instance;
    private SharedPreferences prefs;
    private Gson gson;

    private PortfolioManager(Context context) {
        prefs = context.getApplicationContext()
                       .getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
        // Initialize balance if first time
        if (!prefs.contains(KEY_BALANCE)) {
            prefs.edit().putFloat(KEY_BALANCE, (float) STARTING_BALANCE).apply();
        }
    }

    public static PortfolioManager getInstance(Context context) {
        if (instance == null) instance = new PortfolioManager(context);
        return instance;
    }

    // Get all transactions
    public List<PortfolioItem> getTransactions() {
        String json = prefs.getString(KEY_ITEMS, "[]");
        Type type = new TypeToken<List<PortfolioItem>>(){}.getType();
        List<PortfolioItem> list = gson.fromJson(json, type);
        return list != null ? list : new ArrayList<>();
    }

    // Add a BUY transaction
    public boolean buyStock(String symbol, String company, double price, int qty) {
        double cost = price * qty;
        double balance = getBalance();
        if (cost > balance) return false; // Not enough balance

        List<PortfolioItem> items = getTransactions();
        items.add(new PortfolioItem(symbol, company, price, qty, "BUY"));
        saveTransactions(items);
        setBalance(balance - cost);
        return true;
    }

    // Add a SELL transaction
    public boolean sellStock(String symbol, String company, double price, int qty) {
        List<PortfolioItem> items = getTransactions();
        items.add(new PortfolioItem(symbol, company, price, qty, "SELL"));
        saveTransactions(items);
        double balance = getBalance();
        setBalance(balance + (price * qty));
        return true;
    }

    // Get how many shares user holds of a symbol
    public int getHolding(String symbol) {
        int total = 0;
        for (PortfolioItem item : getTransactions()) {
            if (item.getSymbol().equals(symbol)) {
                if (item.getType().equals("BUY"))  total += item.getQuantity();
                if (item.getType().equals("SELL")) total -= item.getQuantity();
            }
        }
        return Math.max(total, 0);
    }

    // Total invested amount
    public double getTotalInvested() {
        double total = 0;
        for (PortfolioItem item : getTransactions()) {
            if (item.getType().equals("BUY"))
                total += item.getTotalValue();
        }
        return total;
    }

    // Virtual wallet balance
    public double getBalance() {
        return prefs.getFloat(KEY_BALANCE, (float) STARTING_BALANCE);
    }

    private void setBalance(double balance) {
        prefs.edit().putFloat(KEY_BALANCE, (float) balance).apply();
    }

    private void saveTransactions(List<PortfolioItem> items) {
        prefs.edit().putString(KEY_ITEMS, gson.toJson(items)).apply();
    }

    public void resetPortfolio() {
        prefs.edit()
             .putString(KEY_ITEMS, "[]")
             .putFloat(KEY_BALANCE, (float) STARTING_BALANCE)
             .apply();
    }
}
