package com.piyush.stockai.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.piyush.stockai.R;
import com.piyush.stockai.adapters.StockAdapter;
import com.piyush.stockai.models.StockModel;
import com.piyush.stockai.utils.DataProvider;
import com.piyush.stockai.utils.PortfolioManager;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private StockAdapter adapter;
    private TextView tvPortfolioValue, tvPortfolioChange, tvSignalSummary;
    private List<StockModel> currentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        loadStocks();
        setupSearch();
        setupBottomNav();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePortfolioHeader();
    }

    private void initViews() {
        tvPortfolioValue  = findViewById(R.id.tv_portfolio_value);
        tvPortfolioChange = findViewById(R.id.tv_portfolio_change);
        tvSignalSummary   = findViewById(R.id.tv_signal_summary);
        recyclerView = findViewById(R.id.recycler_stocks);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(false);
    }

    private void loadStocks() {
        currentList = DataProvider.getDemoStocks();
        adapter = new StockAdapter(this, currentList);
        recyclerView.setAdapter(adapter);
        updatePortfolioHeader();
    }

    private void updatePortfolioHeader() {
        PortfolioManager pm = PortfolioManager.getInstance(this);
        double balance = pm.getBalance();
        double invested = pm.getTotalInvested();
        double total = balance + invested;

        tvPortfolioValue.setText(String.format("₹%.0f", total));

        double change = total - 100000.0;
        double changePct = (change / 100000.0) * 100;
        String sign = changePct >= 0 ? "▲ +" : "▼ ";
        tvPortfolioChange.setText(String.format("%s%.2f%%  |  Balance: ₹%.0f", sign, Math.abs(changePct), balance));
        tvPortfolioChange.setTextColor(getResources().getColor(
                changePct >= 0 ? R.color.color_buy : R.color.color_sell));

        // Count signals
        int buys = 0, sells = 0;
        for (StockModel s : DataProvider.getAllStocks()) {
            if ("BUY".equals(s.getSignal())) buys++;
            else if ("SELL".equals(s.getSignal())) sells++;
        }
        tvSignalSummary.setText(buys + " BUY  ·  " + sells + " SELL  ·  " + (55 - buys - sells) + " HOLD");
    }

    private void setupSearch() {
        EditText etSearch = findViewById(R.id.et_search);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                List<StockModel> results = DataProvider.search(s.toString());
                adapter.updateList(results);
                // Show hint if nothing found
                if (results.isEmpty()) {
                    tvSignalSummary.setText("No stocks found for \"" + s + "\"");
                } else {
                    tvSignalSummary.setText("Showing " + results.size() + " results");
                }
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void setupBottomNav() {
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);
        bottomNav.setSelectedItemId(R.id.nav_home);
        bottomNav.setOnNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_market) {
                startActivity(new Intent(this, MarketActivity.class));
                overridePendingTransition(0, 0);
                return true;
            } else if (id == R.id.nav_profile) {
                startActivity(new Intent(this, ProfileActivity.class));
                overridePendingTransition(0, 0);
                return true;
            }
            return true;
        });
    }
}
