package com.piyush.stockai.models;

public class StockModel {

    private String symbol;
    private String companyName;
    private double currentPrice;
    private double changePercent;
    private String signal;       // BUY, SELL, HOLD
    private int confidence;      // 0-100
    private double targetPrice;
    private double[] priceHistory;

    public StockModel(String symbol, String companyName, double currentPrice,
                      double changePercent, double[] priceHistory) {
        this.symbol = symbol;
        this.companyName = companyName;
        this.currentPrice = currentPrice;
        this.changePercent = changePercent;
        this.priceHistory = priceHistory;
    }

    // Getters
    public String getSymbol() { return symbol; }
    public String getCompanyName() { return companyName; }
    public double getCurrentPrice() { return currentPrice; }
    public double getChangePercent() { return changePercent; }
    public String getSignal() { return signal; }
    public int getConfidence() { return confidence; }
    public double getTargetPrice() { return targetPrice; }
    public double[] getPriceHistory() { return priceHistory; }

    // Setters
    public void setSignal(String signal) { this.signal = signal; }
    public void setConfidence(int confidence) { this.confidence = confidence; }
    public void setTargetPrice(double targetPrice) { this.targetPrice = targetPrice; }
    public void setPriceHistory(double[] priceHistory) { this.priceHistory = priceHistory; }

    public boolean isPositive() { return changePercent >= 0; }

    public String getFormattedPrice() {
        return String.format("₹%.2f", currentPrice);
    }

    public String getFormattedChange() {
        return String.format("%s%.2f%%", changePercent >= 0 ? "▲ +" : "▼ ", changePercent);
    }

    // Initials for the icon circle
    public String getInitials() {
        if (symbol.length() >= 3) return symbol.substring(0, 3);
        return symbol;
    }
}
