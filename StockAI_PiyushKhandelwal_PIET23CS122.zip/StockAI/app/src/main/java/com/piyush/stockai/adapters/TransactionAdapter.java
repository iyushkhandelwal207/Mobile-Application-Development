package com.piyush.stockai.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.piyush.stockai.R;
import com.piyush.stockai.models.PortfolioItem;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

    private Context context;
    private List<PortfolioItem> items;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault());

    public TransactionAdapter(Context context, List<PortfolioItem> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_transaction, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        PortfolioItem item = items.get(position);
        boolean isBuy = item.getType().equals("BUY");

        h.tvType.setText(item.getType());
        h.tvType.setTextColor(context.getResources().getColor(
                isBuy ? R.color.color_buy : R.color.color_sell));
        h.tvType.setBackgroundResource(isBuy ? R.drawable.badge_buy : R.drawable.badge_sell);

        h.tvSymbol.setText(item.getSymbol());
        h.tvCompany.setText(item.getCompanyName());
        h.tvQty.setText(item.getQuantity() + " shares @ ₹" +
                String.format("%.2f", item.getBuyPrice()));
        h.tvTotal.setText((isBuy ? "-" : "+") + "₹" +
                String.format("%.0f", item.getTotalValue()));
        h.tvTotal.setTextColor(context.getResources().getColor(
                isBuy ? R.color.color_sell : R.color.color_buy));
        h.tvDate.setText(sdf.format(new Date(item.getTimestamp())));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvType, tvSymbol, tvCompany, tvQty, tvTotal, tvDate;
        ViewHolder(View v) {
            super(v);
            tvType    = v.findViewById(R.id.tv_tx_type);
            tvSymbol  = v.findViewById(R.id.tv_tx_symbol);
            tvCompany = v.findViewById(R.id.tv_tx_company);
            tvQty     = v.findViewById(R.id.tv_tx_qty);
            tvTotal   = v.findViewById(R.id.tv_tx_total);
            tvDate    = v.findViewById(R.id.tv_tx_date);
        }
    }
}
