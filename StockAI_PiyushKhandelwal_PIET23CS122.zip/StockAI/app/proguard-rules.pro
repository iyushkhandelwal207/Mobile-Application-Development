# Add project specific ProGuard rules here.
-keep class com.piyush.stockai.models.** { *; }
-keep class com.piyush.stockai.network.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
